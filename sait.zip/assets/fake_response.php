<?php

echo '{"FormResponse": {"success": true, "redirect": ""}}';

?>
