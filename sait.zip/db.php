<?php
require 'libs/rb.php';
 R::setup( 'mysql:host=localhost;dbname=ip_ru', 'Makishimu', 'Astra134' );
 session_start();
 